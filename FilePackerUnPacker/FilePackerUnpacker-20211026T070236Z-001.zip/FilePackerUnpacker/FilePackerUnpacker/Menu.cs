﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace FilePackerUnpacker
{
    public partial class Menu : Form
    {
        public Menu()
        {
            InitializeComponent();
        }

        private void btn_Pack_Click(object sender, EventArgs e)
        {
            Frm_Packing_Portal obj=new Frm_Packing_Portal();
            obj.Show();
            this.Hide();
        }

        private void btn_Unpack_Click(object sender, EventArgs e)
        {
            UnPackingPortal obj = new UnPackingPortal();
            obj.Show();
            this.Hide();
        }

        private void Menu_Load(object sender, EventArgs e)
        {
            label2.Text = DateTime.Now.ToString("dddd , MMM dd yy");
            label1.Text = DateTime.Now.ToString("hh:mm:ss");
        }
    }
}
