﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace FilePackerUnpacker
{
    public partial class UnPackingPortal : Form
    {
        public UnPackingPortal()
        {
            InitializeComponent();
        }

        private void btn_Extract_Here_Click(object sender, EventArgs e)
        {
            string fileName1 = null;
            char[] arr = new char[10];
            char s;
            int i = 0, No = 0;
            fileName1 = tb_File_Name.Text;
            try
            {

                using (StreamReader obj = new StreamReader(fileName1))
                {
                    byte[] header = new byte[100];
                    int length = 0;

                    FileStream fileStream = new FileStream(fileName1, FileMode.Open, FileAccess.Read);

                    while (((length = fileStream.Read(header, 0, 100)) > 0))
                    {
                        String str = Encoding.Default.GetString(header);
                        Console.WriteLine(str);
                        String ext = str.Substring(str.LastIndexOf("/"));
                        ext = ext.Substring(1);
                        String[] words = ext.Split();
                        String filename = words[0];
                        int size = Convert.ToInt32((words[1]));
                        byte[] arr1 = new byte[size];
                        fileStream.Read(arr1, 0, size);

                        FileStream f1 = new FileStream(filename, FileMode.Create, FileAccess.Write, FileShare.None);
                       
                        int p = 0;
                        char key = 'o';
                        char a;
                        foreach (char ch in arr1)
                        {
                      
                            arr1[p] = (byte)(ch ^ key);
                        
                            p++;
                        
                        }  
                        f1.Write(arr1, 0, size);
            

                    }

                }
            }
            catch (Exception b)
            {
                Console.WriteLine(b);
            }
            MessageBox.Show("Unpacked");
            Application.Exit();
           
        }

        private void btn_Exit_Click(object sender, EventArgs e)
        {
            Menu obj = new Menu();
            obj.Show();
            this.Hide();
        }

        private void UnPackingPortal_Load(object sender, EventArgs e)
        {
            label2.Text = DateTime.Now.ToString("dddd , MMM dd yy");
            label1.Text = DateTime.Now.ToString("hh:mm:ss");
        }
    }
}
