﻿namespace FilePackerUnpacker
{
    partial class UnPackingPortal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_Exit = new System.Windows.Forms.Button();
            this.btn_Extract_Here = new System.Windows.Forms.Button();
            this.tb_File_Name = new System.Windows.Forms.TextBox();
            this.lbl_Password = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lbl_File_Packer_UnPacker = new System.Windows.Forms.Label();
            this.lbl_Civilian_Email_ID = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // btn_Exit
            // 
            this.btn_Exit.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.btn_Exit.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Exit.Location = new System.Drawing.Point(853, 393);
            this.btn_Exit.Name = "btn_Exit";
            this.btn_Exit.Size = new System.Drawing.Size(239, 64);
            this.btn_Exit.TabIndex = 54;
            this.btn_Exit.Text = "Back";
            this.btn_Exit.UseVisualStyleBackColor = false;
            this.btn_Exit.Click += new System.EventHandler(this.btn_Exit_Click);
            // 
            // btn_Extract_Here
            // 
            this.btn_Extract_Here.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.btn_Extract_Here.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Extract_Here.Location = new System.Drawing.Point(354, 393);
            this.btn_Extract_Here.Name = "btn_Extract_Here";
            this.btn_Extract_Here.Size = new System.Drawing.Size(239, 64);
            this.btn_Extract_Here.TabIndex = 53;
            this.btn_Extract_Here.Text = "Extract Here";
            this.btn_Extract_Here.UseVisualStyleBackColor = false;
            this.btn_Extract_Here.Click += new System.EventHandler(this.btn_Extract_Here_Click);
            // 
            // tb_File_Name
            // 
            this.tb_File_Name.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.tb_File_Name.Font = new System.Drawing.Font("Microsoft Sans Serif", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_File_Name.Location = new System.Drawing.Point(853, 201);
            this.tb_File_Name.MaxLength = 20;
            this.tb_File_Name.Name = "tb_File_Name";
            this.tb_File_Name.Size = new System.Drawing.Size(382, 49);
            this.tb_File_Name.TabIndex = 52;
            // 
            // lbl_Password
            // 
            this.lbl_Password.AutoSize = true;
            this.lbl_Password.BackColor = System.Drawing.Color.Linen;
            this.lbl_Password.Font = new System.Drawing.Font("Cambria", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Password.ForeColor = System.Drawing.SystemColors.Highlight;
            this.lbl_Password.Location = new System.Drawing.Point(346, 201);
            this.lbl_Password.Name = "lbl_Password";
            this.lbl_Password.Size = new System.Drawing.Size(202, 47);
            this.lbl_Password.TabIndex = 51;
            this.lbl_Password.Text = "File Name";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.SeaShell;
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.lbl_File_Packer_UnPacker);
            this.panel1.Controls.Add(this.lbl_Civilian_Email_ID);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1524, 138);
            this.panel1.TabIndex = 188;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Cambria", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.DarkMagenta;
            this.label2.Location = new System.Drawing.Point(1170, 8);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(222, 38);
            this.label2.TabIndex = 158;
            this.label2.Text = "Day And Date";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Cambria", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.DarkMagenta;
            this.label1.Location = new System.Drawing.Point(1175, 90);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(95, 38);
            this.label1.TabIndex = 157;
            this.label1.Text = "Time";
            // 
            // lbl_File_Packer_UnPacker
            // 
            this.lbl_File_Packer_UnPacker.AutoSize = true;
            this.lbl_File_Packer_UnPacker.Font = new System.Drawing.Font("Cambria", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_File_Packer_UnPacker.ForeColor = System.Drawing.Color.DarkMagenta;
            this.lbl_File_Packer_UnPacker.Location = new System.Drawing.Point(492, 35);
            this.lbl_File_Packer_UnPacker.Name = "lbl_File_Packer_UnPacker";
            this.lbl_File_Packer_UnPacker.Size = new System.Drawing.Size(546, 70);
            this.lbl_File_Packer_UnPacker.TabIndex = 10;
            this.lbl_File_Packer_UnPacker.Text = "File Packing Portal";
            // 
            // lbl_Civilian_Email_ID
            // 
            this.lbl_Civilian_Email_ID.AutoSize = true;
            this.lbl_Civilian_Email_ID.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Civilian_Email_ID.Location = new System.Drawing.Point(195, 489);
            this.lbl_Civilian_Email_ID.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_Civilian_Email_ID.Name = "lbl_Civilian_Email_ID";
            this.lbl_Civilian_Email_ID.Size = new System.Drawing.Size(103, 29);
            this.lbl_Civilian_Email_ID.TabIndex = 154;
            this.lbl_Civilian_Email_ID.Text = "Email ID";
            // 
            // UnPackingPortal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ClientSize = new System.Drawing.Size(1524, 739);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.btn_Exit);
            this.Controls.Add(this.btn_Extract_Here);
            this.Controls.Add(this.tb_File_Name);
            this.Controls.Add(this.lbl_Password);
            this.Name = "UnPackingPortal";
            this.Text = "UnPackingPortal";
            this.Load += new System.EventHandler(this.UnPackingPortal_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_Exit;
        private System.Windows.Forms.Button btn_Extract_Here;
        private System.Windows.Forms.TextBox tb_File_Name;
        private System.Windows.Forms.Label lbl_Password;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lbl_File_Packer_UnPacker;
        private System.Windows.Forms.Label lbl_Civilian_Email_ID;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
    }
}