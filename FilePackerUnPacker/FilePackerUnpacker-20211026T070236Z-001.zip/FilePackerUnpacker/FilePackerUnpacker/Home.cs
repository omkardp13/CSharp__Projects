﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace FilePackerUnpacker
{
    public partial class Home : Form
    {
        public Home()
        {
            InitializeComponent();
        }

        private void lbl_Process_Complaints_Click(object sender, EventArgs e)
        {

        }

        private void btn_Login_Click(object sender, EventArgs e)
        {
            if (tb_Username.Text == "omkar" && tb_Password.Text == "123")
            {
                MessageBox.Show("Login Successfully...!\nWelcome :)");
                Menu obj = new Menu();
                obj.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Invalid Username Or Password!");
            }
        }

        private void btn_Exit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void Home_Load(object sender, EventArgs e)
        {
          label2.Text= DateTime.Now.ToString("dddd , MMM dd yy");
          label1.Text = DateTime.Now.ToString("hh:mm:ss");
            tb_Username.Focus();
        }
    }
}
