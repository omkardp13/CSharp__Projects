﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace FilePackerUnpacker
{
    public partial class Frm_Packing_Portal : Form
    {
        public Frm_Packing_Portal()
        {
            InitializeComponent();
        }

        private void btn_Submit_Click(object sender, EventArgs e)
        {
            String[] ValidExt = { ".txt", ".c",".java", ".cpp" };
            String name = null;
            name = tb_Directory_Name.Text;
            string rootdir = @"D:\" + name + "/";
            string fileName = null;
            fileName = tb_File_Name.Text;
            using (StreamWriter sw = File.CreateText(fileName))
            {

                if (File.Exists(fileName))
                {
                    Console.WriteLine("File Created Successfully");
                }
                else
                {
                    Console.WriteLine("File Not Created ");
                }


                string[] files = Directory.GetFileSystemEntries(rootdir, "*", SearchOption.AllDirectories);
                char[] a = new char[100];
                foreach (string file in files)
                {
                    String ext = file.Substring(file.LastIndexOf("."));

                    List<String> list = new List<string>(ValidExt);

                    if (list.Contains(ext))
                    {

                        using (StreamReader obj = new StreamReader(file))
                        {
                            int no = 0;
                            int sum = 0;
                            int Cnt = 0, temp = 0;
                            string s = file;
                            no = s.Length;

                            FileInfo fi = new FileInfo(file);
                            int size = Convert.ToInt32(fi.Length);
                            sum = Convert.ToInt32(size);
                            temp = sum;
                            while (temp != 0)
                            {
                                Cnt++;
                                temp = temp / 10;
                            }
                          
                            sw.Write(s);
                            sw.Write(" ");
                            sw.Write(size);
                            no = no + Cnt + 1;
                            for (int i = no; i < 100; i++)
                            {
                                sw.Write(" ");
                            }

                            char key='o';
                            char d;
                                while (obj.Peek() >= 0)
                                {
                                       
                                    d = (char)(((char)obj.Read()) ^ key);
                                    sw.Write(d);
                                }
                                                        
                            }
                    }
                    else
                    {
                        Console.WriteLine("Invalid File Extension");
                        Console.ReadKey();
                        System.Environment.Exit(0);
                    }
                }
            }
            MessageBox.Show("Files Packed Successfully");
            Application.Exit();
        }

        private void btn_Exit_Click(object sender, EventArgs e)
        {
            Menu obj = new Menu();
            obj.Show();
            this.Hide();
        }

        private void Frm_Packing_Portal_Load(object sender, EventArgs e)
        {
            label2.Text = DateTime.Now.ToString("dddd , MMM dd yy");
            label1.Text = DateTime.Now.ToString("hh:mm:ss");
        }
    }
}
